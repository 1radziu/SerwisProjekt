<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="logowanie/styleProfil.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Strona Użytkownika</title>
</head>
<body>


<?php
session_start();
if(isset($_SESSION["logged_in_user"])){
    $email = $_SESSION["logged_in_user"];
    $conn = mysqli_connect('localhost','root', '', 'serwis');
    $sql = "SELECT email, password, imie, nazwisko, telefon FROM uzytkownicy WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    // Sprawdzenie, czy zapytanie zwróciło wynik
    if (mysqli_num_rows($result) > 0) {
        // Wyświetlenie danych użytkownika
        $row = mysqli_fetch_assoc($result);
        $email = $row["email"];
        $password = $row["password"];
        $imie = $row["imie"];
        $nazwisko = $row["nazwisko"];
        $phone = $row["telefon"];

        echo '<div id ="container">';
        echo "<div id='avatar'><img src='logowanie/avatarProfil12.png' alt='logo'></div>";
        echo "<ul class='list-group'>";
        echo "<h6>Dane Użytkownika:</h6>";
        echo "<li class='list-group-item'>Email: " . $email . "</li>";
        echo "<li class='list-group-item'>Hasło: " . $password . "</li>";
        echo "<li class='list-group-item'>Imię: " . $imie . "</li>";
        echo "<li class='list-group-item'>Nazwisko: " . $nazwisko . "</li>";
        echo "<li class='list-group-item'>Telefon: " . $phone . "</li>";
        echo "</ul>"; 
        echo '<a href="dodaj.html" class="btn btn-dark" style="color: #F3B54A;">Dodaj Ogłoszenie</a>';
        echo '</div>';
    } 
    
    else {
        echo "Nie znaleziono użytkownika.";
    }
    
    // Zamknięcie połączenia z bazą danych
    mysqli_close($conn);
} 

    ?>
    <footer>MobileGET</footer>
</body>
</html>