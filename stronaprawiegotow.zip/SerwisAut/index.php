<!doctype html>
<html lang="pl">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="styleMain.css">
    <title>Serwis Ogłoszeniowy</title>
  </head>
  <body>
    
      <nav class="navbar navbar-expand-lg bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><img src="image.png" alt="logo" width="150" height="50"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active text-light" aria-current="page" href="index.php">Główna strona</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-light" href="login.html">Zaloguj się </a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link text-light" href="rejestracja.php">Zarejestruj się </a>
            </li>
          </ul>
          <a class="btn btn-dark" href="logowanie/login.html" role="button" style="background-color: #F3B54A ; color: black;">Dodaj ogłoszenie</a>
          
        </div>
      </div>
    </nav>

    <div id="main">
      <form action="szukaj.php" method="post">
      <h2>Znajdź samochód</h2>
      <table>
          <tr>
      <td>
          <div class="mb-3">
              <label class="form-label">Marka:</label>
          <input type="text" class="form-control" style="width: 260px;" name="marka">
      </div>
  </td> 
  
  <td>
      <label id="s1" class="form-label">Przebieg:</label>
      <div class="row">
          <div class="col-sm-5">
            <label id="s1" class="form-label">Od</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="odprzebieg">
              <option selected disabled>Od</option>
              <option value="10000">10 000 km</option>
              <option value="50000">50 000 km</option>
              <option value="100000">100 000 km</option>
            </select>
          </div>
          <div class="col-sm-3">
            <label id="s2" class="form-label">Do</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="doprzebieg">
              <option selected disabled>Do</option>
              <option value="10000">10 000 km</option>
              <option value="50000">50 000 km</option>
              <option value="100000">100 000 km</option>
          </div>
        </div>
  </td> 

</tr>

<tr>
  <td> 
    <div class="col-sm-10">
          <label id="s1" class="form-label">Rodzaj Paliwa:</label>
              <div class="row">
                  <div class="col-sm-5">
                   <select class="form-select" aria-label="Default select example" style="width: 260px;" required name="rodzajpaliwa">
                      <option selected disabled>Wybierz</option>
                      <option value="Elektryk">Elektryczny</option>
                      <option value="Diesel">Diesel</option>
                      <option value="Benzyna">Benzyna</option>
                      <option value="Gaz">Gaz</option>
                      <option value="Wodór">Wodór</option>
                    </select>
                  </div>
      
                </div>
</td> 
  
  <td>

      
      <label id="s1" class="form-label">Moc:</label>
      <div class="row">
          <div class="col-sm-5">
            <label id="s1" class="form-label">Od</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="odmoc">
              <option selected disabled>Od</option>
              <option value="100">100 KM</option>
              <option value="250">250 KM</option>
              <option value="500">500 KM</option>
            </select>
          </div>

          <div class="col-sm-3">
            <label id="s2" class="form-label">Do</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="domoc">
              <option selected disabled>Do</option>
              <option value="100">100 KM</option>
              <option value="250">250 KM</option>
              <option value="500">500 KM</option>
            </select>
          </div>
        </div>
      
   </td> 
  
</tr>

      <tr>
         <td>
          <label id="s1" class="form-label">Rocznik:</label>
          <div class="row">
              <div class="col-sm-4">
                <label id="s1" class="form-label">Od</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="odrok">
                  <option selected disabled>Od</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                  <option value="2020">2020</option>
                  <option value="2019">2019</option>
                  <option value="2018">2018</option>
                  <option value="2017">2017</option>
                  <option value="2016">2016</option>
                  <option value="2015">2015</option>
                  <option value="2014">2014</option>
                  <option value="2013">2013</option>
                  <option value="2012">2012</option>
                  <option value="2011">2011</option>
                  <option value="2010">2010</option>
                  <option value="2009">2009</option>
                  <option value="2008">2008</option>
                  <option value="2007">2007</option>
                  <option value="2006">2006</option>
                  <option value="2005">2005</option>
                  <option value="2004">2004</option>
                  <option value="2003">2003</option>
                  <option value="2002">2002</option>
                  <option value="2001">2001</option>
                  <option value="2000">2000</option>
                </select>
              </div>
              <div class="col-sm-3">
                <label id="s2" class="form-label">Do</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="dorok">
                  <option selected disabled>Do</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                  <option value="2020">2020</option>
                  <option value="2019">2019</option>
                  <option value="2018">2018</option>
                  <option value="2017">2017</option>
                  <option value="2016">2016</option>
                  <option value="2015">2015</option>
                  <option value="2014">2014</option>
                  <option value="2013">2013</option>
                  <option value="2012">2012</option>
                  <option value="2011">2011</option>
                  <option value="2010">2010</option>
                  <option value="2009">2009</option>
                  <option value="2008">2008</option>
                  <option value="2007">2007</option>
                  <option value="2006">2006</option>
                  <option value="2005">2005</option>
                  <option value="2004">2004</option>
                  <option value="2003">2003</option>
                  <option value="2002">2002</option>
                  <option value="2001">2001</option>
                  <option value="2000">2000</option>
                </select>
              </div>
            </div>
            
         </td> 
         
         <td>

          <label id="s1" class="form-label">Cena:</label>
          <div class="row">
              <div class="col-sm-5">
                <label id="s1" class="form-label">Od</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="odcena">
                  <option selected disabled>Od</option>
                  <option value="10000">10 000 PLN</option>
                  <option value="50000">50 000 PLN</option>
                  <option value="100000">100 000 PLN</option>
                  <option value="500000">500 000 PLN</option>
                </select>
              </div>
              <div class="col-sm-3">
                <label id="s2" class="form-label">Do</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;" required name="docena">
                  <option selected disabled>Do</option>
                  <option value="10000">10 000 PLN</option>
                  <option value="50000">50 000 PLN</option>
                  <option value="100000">100 000 PLN</option>
                  <option value="500000">500 000 PLN</option>
                </select>
              </div>
            </div>


         </td> 
         
      </tr>

      <tr>
          <td>
              </td>
              <td>
                  <input type="submit" class="btn btn-warning" style="margin-top: 10px; width: 85px;" value="Szukaj">
              </td>
      </tr>
      
  </table>
  
</div>
</form>
<div id="container">
  <?php
  error_reporting(0);
  $conn = mysqli_connect('localhost','root', '', 'serwis');
    $sql = "SELECT model, marka, rocznik, przebieg, moc, cena, paliwo FROM samochody";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)){
      
      echo"<div class='card' style='width: 18rem;'>";
      echo    "<div class='card-body'>";
            echo "<ul class='list-group'>";
              echo "<li class='list-group-item'>Marka: " .$row['model']."</li>";
              echo "<li class='list-group-item'>Model: " .$row['marka']."</li>";
              echo "<li class='list-group-item'>Rok: " .$row['rocznik']. "</li>";
              echo "<li class='list-group-item'>Przebieg: " .$row['przebieg']. "</li>";
              echo "<li class='list-group-item'>Moc: " .$row['moc']."</li>";
              echo "<li class='list-group-item'>Cena: " .$row['cena']. "</li>";
              echo "<li class='list-group-item'>Paliwo: " .$row['paliwo']. "</li>";
            echo"</ul>";
         echo "</div>";
        echo "</div>";
    }
   ?>
  </div>
      
  </div>
  </div>
   
<footer>MobileGET</footer>

  </body>
</html>
