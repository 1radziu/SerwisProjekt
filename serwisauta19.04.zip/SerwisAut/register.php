<?php
    error_reporting(0);

    $email = $_POST["email"];
    $haslo = $_POST["haslo"];
    $imie = $_POST["imie"];
    $nazwisko = $_POST["nazwisko"];
    $telefon = $_POST["telefon"];
    $haslo2 = $_POST['haslo2'];

    $conn = mysqli_connect("localhost","root","","xdxd");
    
    if($email != "" && $haslo != "" && $haslo2 != "" && $imie != "" && $nazwisko != "" && $telefon != "" ){
        if($haslo == $haslo2){
        
        $sql = "INSERT INTO uzytkownicy(email,password,imie,nazwisko,telefon) values ('$email','$haslo','$imie','$nazwisko',$telefon)";
        }
        else{
            echo "Hasła nie są takie same ! <a href='index.php'>Wróć</a>";
        }
    }
    else{
        echo "Wypełnij wszystkie pola !  <a href='index.php'>Wróć</a>";
    }
    mysqli_query($conn,$sql);
    require_once("index.html")
    ?>