<?php
    $marka = $_POST["marka"];
    $model = $_POST["model"];
    $rocznik = $_POST["rocznik"];
    $przebieg = $_POST["przebieg"];
    $moc = $_POST["moc"];
    $cena = $_POST["cena"];
    $rodzajpaliwa = $_POST["rodzajpaliwa"];
/*     $email = $_SESSION["email"];  */
    $conn = mysqli_connect("localhost","root","","xdxd");
    $sql = "INSERT INTO samochody (marka, model, rocznik, moc, przebieg, cena, paliwo) VALUES ('$marka', '$model', $rocznik, $moc, $przebieg, $cena, '$rodzajpaliwa')";

        if($marka != "" && $model != "" && $rocznik != "" && $moc != "" && $cena != "" && $przebieg != "" && $rodzajpaliwa != ""){
            mysqli_query($conn,$sql);
            require_once("index.php");
        }
        else{
            echo "Uzupełnij wszyskie luki <a href='dodaj.html'>Wróć</a>";
            echo $email;
        }
    ?>
