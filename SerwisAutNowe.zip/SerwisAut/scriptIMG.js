function checkImageDimensions(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        var img = new Image();
        img.onload = function() {
          if (img.width > 280 || img.height > 280) {
            alert('Wybrane zdjęcie przekracza limit rozmiaru 800x600 pikseli');
            input.value = '';
          } else {
            document.getElementById('preview').src = e.target.result;
          }
        };
        img.src = e.target.result;
      }
      reader.readAsDataURL(input.files[0]);
    }
  }