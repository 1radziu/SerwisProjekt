<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleRegister.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Rejestracja</title>
</head>
<body>
<form action="register.php" method="POST">



        <div id="RegisterDiv">

            <img src="image.png" alt="logo">
            <div class="mb-2">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Wprowadź" aria-describedby="emailHelp" name="email" style="width: 350px; height: 30px;">
                
                <label for="exampleInputPassword1" class="form-label">Hasło</label>
                <input type="password" class="form-control" placeholder="Wprowadź" id="exampleInputPassword1" name="haslo" style="width: 350px; height: 30px;">
                
                <label for="exampleInputPassword2" class="form-label">Powtórz hasło</label>
                <input type="password" class="form-control" placeholder="Wprowadź" id="exampleInputPassword1" name="haslo2" style="width: 350px; height: 30px;">
                
                <label for="Imie" class="form-label">Imię</label>
                <input type="text" class="form-control" id="Imie" placeholder="Wprowadź" aria-describedby="NameHelp" name="imie" style="width: 350px; height: 30px;">
                
                <label for="Nazwisko" class="form-label"> Nazwisko</label>
                <input type="text" class="form-control" id="Nazwisko" placeholder="Wprowadź" aria-describedby="SurnameHelp" name="nazwisko" style="width: 350px; height: 30px;">
                
                <label for="NumberTelefonu" class="form-label">Number telefonu</label>
                <input type="text" class="form-control" id="NumberTelefonu" placeholder="Wprowadź" aria-describedby="PhoneNumberHelp" name="telefon" style="width: 350px; height: 30px;">
                
            </div>
            
                <button type="submit" class="btn btn-dark" style="color: #F3B54A">Zarejestruj się</button>
        </div>
        </form>
    
    
</table>
</form>


    <footer>MobileGET</footer>
</body>
</html>