<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="add.php" method="POST">
        <table>
        <tr><td>Marka</td><td><input type="text" name = "marka" placeholder="marka"></td></tr>
        <tr><td>Model</td><td><input type="text" name = "model" placeholder="model"></td></tr>
        <tr><td>Rocznik</td><td><input type="number" max='2023' min='1900' name = "rocznik" placeholder="Od"></td></tr>
        <tr><td>Przebieg</td><td><input type="number"  name = "przebieg" min='0' max='9999999' placeholder="Od "></td></tr>
        <tr><td>Moc</td><td><input type="number" name = "moc" placeholder="Od " min='0' max='9999'></td></tr>
        <tr><td>Cena</td><td><input type="number" name = "cena" placeholder="Od"  min='0' max='9999999'></td></tr>
        <tr><td>Rodzaj paliwa</td><td><select name = "rodzajpaliwa" placeholder="Wybierz ">
            <option value="Elektryk">Elektryczny</option>
            <option value="Diesel">Diesel</option>
            <option value="Benzyna">Benzyna</option>
            <option value="Gaz">Gaz</option>
            <option value="Wodór">Wodór</option>
        </select></td></tr>
</table>
<input type="submit" value="Wyślij">
    </form>
</body>
</html>