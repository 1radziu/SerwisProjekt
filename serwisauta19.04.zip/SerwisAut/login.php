<?php
    $email = $_POST['email'];
    $haslo = $_POST['haslo'];

    $conn = mysqli_connect("localhost","root","","xdxd");
    $sql1 = "SELECT email, password from uzytkownicy where email = '$email' && password = '$haslo'";
    $que = mysqli_query($conn, $sql1);
    $rows = mysqli_num_rows($que);

    if($rows>0){
        $_SESSION["loggedin"] = true;
        $_SESSION["email"] = $email; 
    }
    else{
        echo "Hasło lub Email jest niepoprawny";
    };
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
        echo "Witaj użytkowniku $email ";
        echo "<a href=dodaj.html> Dodaj ogłoszenie <a>";
        
    }
    else{
        header("login.html");
    }
?>