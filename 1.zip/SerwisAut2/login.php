<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    #container{
      padding: 20px;
    }
    #cos{
      background-color: azure;
    }
    .ogl{
      display:flex;
      flex-direction: row;
      flex-wrap: wrap;
    }
  </style>
<?php
    $email = $_POST['email'];
    $haslo = $_POST['haslo'];

    $conn = mysqli_connect("localhost","root","","xdxd");
    $sql1 = "SELECT email, password from uzytkownicy where email = '$email' && password = '$haslo'";
    $que = mysqli_query($conn, $sql1);
    $rows = mysqli_num_rows($que);

    if($rows>0){
        $_SESSION["loggedin"] = true;
        $_SESSION["email"] = $email; 
    }
    else{
        header("login.html");
    };
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
        
    }
    else{
        header("login.html");
    }
?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login_php.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
    <div id="cos">
        <div id="profil">
        <?php
          
                $conn = mysqli_connect('localhost','root', '', 'serwis');
                $sql = "SELECT email, password, imie, nazwisko, telefon FROM uzytkownicy WHERE email='$email'";
                $result = mysqli_query($conn, $sql);

                // Sprawdzenie, czy zapytanie zwróciło wynik
                if (mysqli_num_rows($result) > 0) {
                    // Wyświetlenie danych użytkownika
                    $row = mysqli_fetch_assoc($result);
                    $email = $row["email"];
                    $password = $row["password"];
                    $imie = $row["imie"];
                    $nazwisko = $row["nazwisko"];
                    $phone = $row["telefon"];

                    echo '<div id ="container">';
                    echo "<ul class='list-group'>";
                    echo "<h6>Dane Użytkownika:</h6>";
                    echo "<li class='list-group-item'>Email: " . $email . "</li>";
                    echo "<li class='list-group-item'>Hasło: " . $password . "</li>";
                    echo "<li class='list-group-item'>Imię: " . $imie . "</li>";
                    echo "<li class='list-group-item'>Nazwisko: " . $nazwisko . "</li>";
                    echo "<li class='list-group-item'>Telefon: " . $phone . "</li>";
                    echo "</ul>"; 
                    echo '</div>';
                } 
                
                else {
                    echo "Nie znaleziono użytkownika.";
                }
                
                // Zamknięcie połączenia z bazą danych
                mysqli_close($conn);
        
        ?>
        
        </div>
        <h3>Moje Ogłoszenia</h3>

        <div class="ogl">
        <?php 
          $email = $_POST['email'];
          $conn = mysqli_connect('localhost','root', '', 'serwis');
          $sql = "SELECT model, marka, rocznik, przebieg, moc, cena, paliwo FROM samochody where email = '$email'";
          $result = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_assoc($result)){
            
            echo"<div class='card' style='width: 18rem;'>";
            echo    "<div class='card-body'>";
                  echo "<ul class='list-group'>";
                    echo "<li class='list-group-item'>Marka: " .$row['model']."</li>";
                    echo "<li class='list-group-item'>Model: " .$row['marka']."</li>";
                    echo "<li class='list-group-item'>Rok: " .$row['rocznik']. "</li>";
                    echo "<li class='list-group-item'>Przebieg: " .$row['przebieg']. "</li>";
                    echo "<li class='list-group-item'>Moc: " .$row['moc']."</li>";
                    echo "<li class='list-group-item'>Cena: " .$row['cena']. "</li>";
                    echo "<li class='list-group-item'>Paliwo: " .$row['paliwo']. "</li>";
                  echo"</ul>";
               echo "</div>";
              echo "</div>";
          }
          ?>
        </div>
    </div>
    
    <div id="ogloszenie">
    <form action="add.php" method="POST">
    <h2>Dodaj samochód</h2>
            <table>
                <tr>
            <td>
                <div class="mb-3">
                    <label class="form-label" color="white">Marka:</label>
                <input type="text" name="marka" class="form-control" style="width: 280px;">
            </div>
        </td> 
        
        <td>
            <label id="s1" class="form-label" color="white">Przebieg:</label>
            <div class="row">
                <div class="col-sm-5">
                  <label id="s1" class="form-label"></label>
                  <input type="number"  name = "przebieg" min='0' max='9999999' class="form-select" aria-label="Default select example" style="width: 100px;">
                </div>
              </div>
        </td> 
        
        <td> <label id="s1" class="form-label" color="white">Rodzaj Paliwa:</label>
            <div class="row">
                <div class="col-sm-5">
                 <select name="paliwo" class="form-select" aria-label="Default select example" style="width: 180px;">
                    <option selected>Wybierz</option>
                    <option value="Elektryk">Elektryczny</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Benzyna">Benzyna</option>
                    <option value="Gaz">Gaz</option>
                    <option value="Wodór">Wodór</option>
                  </select>
                </div>
    
              </div>
            </td>
    </tr>
    
    <tr>
        <td> 
             <div class="mb-3">
            <label class="form-label" color="white">Model:</label>
          <input type="text" name="model" class="form-control" style="width: 280px;">
        </div>
    </td> 
        
        <td>

            
            <label id="s1" class="form-label" color="white">Moc:</label>
            <div class="row">
                <div class="col-sm-5">
                  <label id="s1" class="form-label"></label>
                  <input type="number" name = "moc" placeholder="Od " min='0' max='9999' class="form-select" aria-label="Default select example" style="width: 100px;">

                </div>

                <div class="col-sm-3">


                </div>
              </div>
            
         </td> 
        
        <td>
            <div class="mb-3">

        </div>
        </td>
    </tr>
    
            <tr>
               <td>
                <label id="s1" class="form-label" color="white">Rocznik:</label>
                <div class="row">
                    <div class="col-sm-5">
                      <label id="s1" class="form-label"></label>
                      <input type="number" max='2023' min='2000' name = "rocznik" class="form-select" aria-label="Default select example" style="width: 100px;">
                    </div>
                    <div class="col-sm-3">
                      <label id="s2" class="form-label"></label>
                    </div>
                  </div>
                  

               </td> 
               
               <td>

                <label id="s1" class="form-label" color="white">Cena:</label>
                <div class="row">
                    <div class="col-sm-5">
                      <label id="s1" class="form-label"></label>
                      <input type="number" name = "cena" placeholder="Od"  min='0' max='9999999' class="form-select" aria-label="Default select example" style="width: 100px;">
                      <div class="mb-3">
                    <label class="form-label">Email do kontaktu:</label>
                  <input type="email" name="email" class="form-control" style="width: 280px;">
                </div>
                    </div>
                    <div class="col-sm-3">
                    

                    </div>
                  </div>


               </td> 
               
            </tr>
            
        </table>

        <input type="submit" class="btn btn-warning" style="margin-top: 85px; width: 150px;" value="Dodaj Ogłoszenie">


        <img id="preview">
    </div>
</body>
</html>