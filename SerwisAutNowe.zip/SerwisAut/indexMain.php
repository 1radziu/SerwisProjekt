<!doctype html>
<html lang="pl">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="styleMainUpgrade.css">
    <title>Serwis Ogłoszeniowy</title>
  </head>
  <body>
    
      <nav class="navbar navbar-expand-lg bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.html"><img src="image.png" alt="logo" width="150" height="50"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active text-light" aria-current="page" href="index.html">Główna strona</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-light" href="login.html">Zaloguj się </a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link text-light" href="index.php">Zarejestruj się </a>
            </li>
          </ul>
          <a class="btn btn-dark" href="login.html" role="button" style="background-color: #F3B54A ; color: black;">Dodaj ogłoszenie</a>
          
        </div>
      </div>
    </nav>

    <div id="main">
      <h2>Znajdź samochód</h2>
      <table>
          <tr>
      <td>
          <div class="mb-3">
              <label class="form-label">Marka:</label>
          <input type="text" class="form-control" style="width: 260px;">
      </div>
  </td> 
  
  <td>
      <label id="s1" class="form-label">Przebieg:</label>
      <div class="row">
          <div class="col-sm-5">
            <label id="s1" class="form-label">Od</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;">
              <option selected>Od</option>
              <option value="1">10 000 km</option>
              <option value="2">50 000 km</option>
              <option value="3">100 000 km</option>
            </select>
          </div>
          <div class="col-sm-3">
            <label id="s2" class="form-label">Do</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;">
              <option selected>Do</option>
              <option value="1">10 000 km</option>
              <option value="2">50 000 km</option>
              <option value="3">100 000 km</option>
          </div>
        </div>
  </td> 

</tr>

<tr>
  <td> 
    <div class="col-sm-10">
      <label for="validationCustom04" class="form-label">Model</label>
      <select class="form-select" id="validationCustom04" required>
        <option selected disabled value="">Model</option>
        <option>SUV</option>
        <option>EKO</option>
        <option>Sportowy</option>
        <option>Osobowy</option>
      </select>
</td> 
  
  <td>

      
      <label id="s1" class="form-label">Moc:</label>
      <div class="row">
          <div class="col-sm-5">
            <label id="s1" class="form-label">Od</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;">
              <option selected>Od</option>
              <option value="1">100 KM</option>
              <option value="2">250 KM</option>
              <option value="3">500KM</option>
            </select>
          </div>

          <div class="col-sm-3">
            <label id="s2" class="form-label">Do</label>
            <select class="form-select" aria-label="Default select example" style="width: 100px;">
              <option selected>Od</option>
              <option value="1">100 KM</option>
              <option value="2">250 KM</option>
              <option value="3">500 KM</option>
            </select>
          </div>
        </div>
      
   </td> 
  
</tr>

      <tr>
         <td>
          <label id="s1" class="form-label">Rocznik:</label>
          <div class="row">
              <div class="col-sm-4">
                <label id="s1" class="form-label">Od</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;">
                  <option selected>Od</option>
                  <option value="1">2023</option>
                  <option value="2">2022</option>
                  <option value="3">2021</option>
                  <option value="4">2020</option>
                  <option value="5">2019</option>
                  <option value="6">2018</option>
                  <option value="7">2017</option>
                  <option value="8">2016</option>
                  <option value="9">2015</option>
                  <option value="10">2014</option>
                  <option value="11">2013</option>
                  <option value="12">2012</option>
                  <option value="13">2011</option>
                  <option value="14">2010</option>
                  <option value="15">2009</option>
                  <option value="16">2008</option>
                  <option value="17">2007</option>
                  <option value="18">2006</option>
                  <option value="19">2005</option>
                  <option value="20">2004</option>
                  <option value="21">2003</option>
                  <option value="22">2002</option>
                  <option value="23">2001</option>
                  <option value="24">2000</option>
                </select>
              </div>
              <div class="col-sm-3">
                <label id="s2" class="form-label">Do</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;">
                  <option selected>Do</option>
                  <option value="1">2023</option>
                  <option value="2">2022</option>
                  <option value="3">2021</option>
                  <option value="4">2020</option>
                  <option value="5">2019</option>
                  <option value="6">2018</option>
                  <option value="7">2017</option>
                  <option value="8">2016</option>
                  <option value="9">2015</option>
                  <option value="10">2014</option>
                  <option value="11">2013</option>
                  <option value="12">2012</option>
                  <option value="13">2011</option>
                  <option value="14">2010</option>
                  <option value="15">2009</option>
                  <option value="16">2008</option>
                  <option value="17">2007</option>
                  <option value="18">2006</option>
                  <option value="19">2005</option>
                  <option value="20">2004</option>
                  <option value="21">2003</option>
                  <option value="22">2002</option>
                  <option value="23">2001</option>
                  <option value="24">2000</option>
                </select>
              </div>
            </div>
            
         </td> 
         
         <td>

          <label id="s1" class="form-label">Cena:</label>
          <div class="row">
              <div class="col-sm-5">
                <label id="s1" class="form-label">Od</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;">
                  <option selected>Od</option>
                  <option value="1">10 000 PLN</option>
                  <option value="2">50 000 PLN</option>
                  <option value="3">100 000 PLN</option>
                  <option value="4">500 000 PLN</option>
                </select>
              </div>
              <div class="col-sm-3">
                <label id="s2" class="form-label">Do</label>
                <select class="form-select" aria-label="Default select example" style="width: 100px;">
                  <option selected>Do</option>
                  <option value="1">10 000 PLN</option>
                  <option value="2">50 000 PLN</option>
                  <option value="3">100 000 PLN</option>
                  <option value="4">500 000 PLN</option>
                </select>
              </div>
            </div>


         </td> 
         
      </tr>

      <tr>
          <td><label id="s1" class="form-label">Rodzaj Paliwa:</label>
              <div class="row">
                  <div class="col-sm-5">
                   <select class="form-select" aria-label="Default select example" style="width: 260px;">
                      <option selected>Wybierz</option>
                      <option value="Elektryk">Elektryczny</option>
                      <option value="Diesel">Diesel</option>
                      <option value="Benzyna">Benzyna</option>
                      <option value="Gaz">Gaz</option>
                      <option value="Wodór">Wodór</option>
                    </select>
                  </div>
      
                </div>
              </td>
              <td>
                  <button type="button" class="btn btn-warning" style="margin-top: 10px; width: 85px;">Szukaj</button>
              </td>
      </tr>
      
  </table>
  
</div>
</form>

<?php
  $conn = mysqli_connect('localhost','root', '', 'serwis');
    $sql = "SELECT model, marka, rocznik, przebieg, cena, paliwo FROM samochody";
    $result = mysqli_query($conn, $sql);

    // Sprawdzenie, czy zapytanie zwróciło wynik
    if (mysqli_num_rows($result) > 0) {
        // Wyświetlenie danych użytkownika
        $row = mysqli_fetch_assoc($result);
        $marka = $_POST["marka"];
        $model = $_POST["model"];
        $rocznik = $_POST["rocznik"];
        $przebieg = $_POST["przebieg"];
        $moc = $_POST["moc"];
        $cena = $_POST["cena"];
        $rodzajpaliwa = $_POST["rodzaj_paliwa"];

  echo "<div id='container'>";

  echo"<div class='card' style='width: 18rem;'>";
  echo  "<img src='samochody/honda_Civic2018.jpg' class='card-img-top' style='height: 150px;'>";
  echo    "<div class='card-body'>";
        echo "<ul class='list-group'>";
          echo "<li class='list-group-item'>Marka:" .$marka."</li>";
          echo "<li class='list-group-item'>Model:" .$model."</li>";
          echo "<li class='list-group-item'>An" .$rocznik. "</li>";
          echo "<li class='list-group-item'>An" .$przebieg. "</li>";
          echo "<li class='list-group-item'>An" .$moc."</li>";
          echo "<li class='list-group-item'>An" .$cena. "</li>";
          echo "<li class='list-group-item'>An" .$rodzajpaliwa. "</li>";
        echo"</ul>";
     echo "</div>";
    echo"</div>";

    mysqli_close($conn);
    }
    else{
      echo"brak samochodów";
    }
   ?>
    <div class="card" style="width: 18rem;">
      <img src="samochody/volkswagen-passat-2017-recall.jpg" class="card-img-top" alt="..." style="height: 150px;">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">An item</li>
          <li class="list-group-item">A second item</li>
          <li class="list-group-item">A third item</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
        </ul>
    </div>
    </div>

    <div class="card" style="width: 18rem;">
      <img src="samochody/focus_ford.jpg" class="card-img-top" alt="..." style="height: 150px;">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">An item</li>
          <li class="list-group-item">A second item</li>
          <li class="list-group-item">A third item</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
        </ul>

      </div>

      
      
  </div>
  </div>
  
  <div id="container1">
    <div class="card" style="width: 18rem;">
      <img src="samochody/a3_audi.jpg" class="card-img-top" alt="..." style="height: 150px;">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">An item</li>
          <li class="list-group-item">A second item</li>
          <li class="list-group-item">A third item</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
        </ul>
      </div>
    </div>
   

    <div class="card" style="width: 18rem;">
      <img src="samochody/clio_renault.jpg" class="card-img-top" alt="..." style="height: 150px;">
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">An item</li>
          <li class="list-group-item">A second item</li>
          <li class="list-group-item">A third item</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
          <li class="list-group-item">A fourth item</li>
          <li class="list-group-item">And a fifth one</li>
        </ul>

      </div>
      
  </div>
  </div>
   
<footer>MobileGET</footer>

  </body>
</html>
