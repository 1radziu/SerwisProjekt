<?php
    $email = $_POST['email'];
    $haslo = $_POST['haslo'];

    $conn = mysqli_connect("localhost","root","","xdxd");
    $sql1 = "SELECT email, password from uzytkownicy where email = '$email' && password = '$haslo'";
    $que = mysqli_query($conn, $sql1);
    $rows = mysqli_num_rows($que);

    if($rows>0){
        $_SESSION["loggedin"] = true;
        $_SESSION["email"] = $email; 
    }
    else{
        echo "Hasło lub Email jest niepoprawny";
    };
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
        echo "Witaj użytkowniku $email <br>";
        /* Wykaz wszystkich ogłoszeń użytkownika używając klauzuli email = "$email" */
        
    }
    else{
        header("login.html");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div id="ogloszenie">
    Dodawanie ogłoszenia
    <form action="add.php" method="POST">
        <table>
            <tr><td>Marka</td><td><input type="text" name = "marka" placeholder="marka"></td></tr>
            <tr><td>Model</td><td><input type="text" name = "model" placeholder="model"></td></tr>
            <tr><td>Rocznik</td><td><input type="number" max='2023' min='1900' name = "rocznik" placeholder="Od"></td></tr>
            <tr><td>Przebieg</td><td><input type="number"  name = "przebieg" min='0' max='9999999' placeholder="Od "></td></tr>
            <tr><td>Moc</td><td><input type="number" name = "moc" placeholder="Od " min='0' max='9999'></td></tr>
            <tr><td>Cena</td><td><input type="number" name = "cena" placeholder="Od"  min='0' max='9999999'></td></tr>
            <tr><td>Rodzaj paliwa</td><td><select name = "rodzajpaliwa" placeholder="Wybierz ">
                <option value="Elektryk">Elektryczny</option>
                <option value="Diesel">Diesel</option>
                <option value="Benzyna">Benzyna</option>
                <option value="Gaz">Gaz</option>
                <option value="Wodór">Wodór</option>
            </select></td></tr>
    </table>
    <input type="submit" value="Wyślij">
    </form>
    </div>
    <?php 
        /* $email = $_SESSION['email'];
        $sql = "Select * from samochody where email = '$email'" */
    ?> 
</body>
</html>