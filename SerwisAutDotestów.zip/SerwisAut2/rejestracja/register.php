<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background-color: #1A0069;
            color:white;
        }
        a{
            text-decoration: none;
            font-size: 200%;
            color: white;
            font-weight: 600;
        }
    </style>
</head>
<body>
<?php
    $email = $_POST["email"];
    $haslo = $_POST["haslo"];
    $imie = $_POST["imie"];
    $nazwisko = $_POST["nazwisko"];
    $telefon = $_POST["telefon"];
    $haslo2 = $_POST["haslo2"];
    $conn = mysqli_connect("localhost","root","","serwis");

    $sql = "INSERT INTO uzytkownicy(email,password,imie,nazwisko,telefon) values ('$email','$haslo','$imie','$nazwisko',$telefon)";

    if ($haslo == $haslo2)
    {
         mysqli_query($conn,$sql);
         require_once('index.php');
     }
    else
    {
        echo '<h4>Coś poszło nie tak</h4>';
        echo 'Zarejestruj się jeszcze raz <a href="">Wróć</a>';
    }
    ?>
</body>
</html>