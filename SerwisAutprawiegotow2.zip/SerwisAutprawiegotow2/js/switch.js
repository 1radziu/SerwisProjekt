let btn_bg = document.querySelector('#btn_bg');
let btn = document.querySelector('#circle');
let main = document.querySelector('#main');
let main_btn = document.querySelector('.btn-warning');
let main_inp = document.querySelectorAll('.form-select');
let main_inp2 = document.querySelectorAll('.form-control');
let tbody = document.querySelector('tbody');
let card = document.querySelectorAll('.card')
let col = `rgb(216, 217, 222)`;
btn_bg.addEventListener('click', ()=> {
    if (document.body.style.backgroundColor == col)
    {
        //body
        document.body.style.backgroundColor = '#393B45';
        //<-
        //main
        main.style.backgroundColor = '#F3B54A';
        main_btn.style.backgroundColor = '#393B45';
        main_btn.style.color = '#F3B54A';
        main.style.color = '#393B45';

        for(let i = 0; i < main_inp.length; i++) {
            main_inp[i].style.backgroundColor = '#393B45';
            main_inp[i].style.color = '#F3B54A';
        }
        for(let i = 0; i < main_inp2.length; i++) {
            main_inp2[i].style.backgroundColor = '#393B45';
            main_inp2[i].style.color = '#F3B54A';
        }
        for(let i = 0; i < card.length; i++) {
            card[i].style.backgroundColor = '#6E7889';
        }
        //<-
        btn.style.margin = '5px 5px 5px 25px';
        btn_bg.style.backgroundColor = '#6E7889';
        btn.style.transition = 'all 300ms';
    }
    else {
        //body
        document.body.style.backgroundColor = '';
        //<-
        //main
        main.style.backgroundColor = '';
        main_btn.style.backgroundColor = '';
        main_btn.style.color = '';
        main.style.color = '';

        for(let i = 0; i < main_inp.length; i++) {
            main_inp[i].style.backgroundColor = '';
            main_inp[i].style.color = '';
        }
        for(let i = 0; i < main_inp2.length; i++) {
            main_inp2[i].style.backgroundColor = '';
            main_inp2[i].style.color = '';
        }
        for(let i = 0; i < card.length; i++) {
            card[i].style.backgroundColor = '';
        }
        //<-
        btn.style.margin = '5px 25px 5px 5px';
        btn_bg.style.backgroundColor = '';
    }
})