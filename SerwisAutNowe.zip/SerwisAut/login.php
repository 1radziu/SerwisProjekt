<?php
session_start();
error_reporting(0);
$_SESSION['logged_in_user'] = $email;
$email = $_POST['email'];
$haslo = $_POST['haslo'];

$conn = mysqli_connect("localhost","root","","serwis");
$sql1 = "SELECT email, password from uzytkownicy where email = '$email' && password = '$haslo'";
$que = mysqli_query($conn, $sql1);
$rows = mysqli_num_rows($que);

if($rows > 0){
    $_SESSION["logged_in_user"] = $email;
    $_SESSION["loggedin"] = true;
    $_SESSION["email"] = $email; 
    header('Location: profil.php');
} else {
    echo "Hasło lub Email jest niepoprawny";
}
?>
