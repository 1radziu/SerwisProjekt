<?php
    $marka = $_POST["marka"];
    $model = $_POST["model"];
    $rocznik = $_POST["rocznik"];
    $przebieg = $_POST["przebieg"];
    $moc = $_POST["moc"];
    $cena = $_POST["cena"];
    $email = $_POST["email"];
    $rodzajpaliwa = $_POST["paliwo"];
    $conn = mysqli_connect("localhost","root","","serwis");
    $sql = "INSERT INTO samochody (marka, model, rocznik, moc, przebieg, cena, paliwo, email) VALUES ('$marka', '$model', $rocznik, $moc, $przebieg, $cena, '$rodzajpaliwa', '$email')";

        if($marka != "" && $model != "" && $rocznik != "" && $moc != "" && $cena != "" && $przebieg != "" && $rodzajpaliwa != ""){
            mysqli_query($conn,$sql);
            require_once("index.php");
        }
        else{
            echo "Uzupełnij wszyskie luki <a href='login.php'>Wróć</a>";
        }
    ?>
