<!doctype html>
<html lang="pl">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="styleMain.css">
    <title>Serwis Ogłoszeniowy</title>
  </head>
  <body>
    
      <nav class="navbar navbar-expand-lg bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><img src="image.png" alt="logo" width="150" height="50"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active text-light" aria-current="page" href="index.php">Główna strona</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-light" href="login.html">Zaloguj się </a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link text-light" href="rejestracja.php">Zarejestruj się </a>
            </li>
          </ul>
          <a class="btn btn-dark" href="logowanie/login.html" role="button" style="background-color: #F3B54A ; color: black;">Dodaj ogłoszenie</a>
          
        </div>
      </div>
    </nav>
<center><h1>Wyniki wyszukiwania</h1></center> <!-- Napisał <center> Maciej Piotrowski, Powód nie chciało mi się pisać w CSS text-align:center -->
<div id="container">
  <?php
    error_reporting(0);
    $marka = $_POST["marka"];
    $odprzebieg = $_POST["odprzebieg"];
    $doprzebieg = $_POST["doprzebieg"];
    $odmoc = $_POST["odmoc"];
    $domoc = $_POST["domoc"];
    $odrok = $_POST["odrok"];
    $dorok = $_POST["dorok"];
    $odcena = $_POST["odcena"];
    $docena = $_POST["docena"];
    $rodzajpaliwa = $_POST["rodzajpaliwa"];

    $odprzebieg = intval($odprzebieg);
    $doprzebieg = intval($doprzebieg);
    $odmoc = intval($odmoc);
    $domoc = intval($domoc);
    $odcena = intval($odcena);
    $docena = intval($docena);
    $odrok = intval($odrok);
    $dorok = intval($dorok);

  error_reporting(0);
  $conn = mysqli_connect('localhost','root', '', 'serwis');
    $sql = "SELECT model, marka, rocznik, przebieg, moc, cena, paliwo FROM samochody where marka = '$marka' && paliwo = '$rodzajpaliwa' && rocznik between $odrok and $dorok && moc between $odmoc and $domoc && przebieg between $odprzebieg and $doprzebieg && cena between $odcena and $docena";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)){
      
      echo"<div class='card' style='width: 18rem;'>";
      echo    "<div class='card-body'>";
            echo "<ul class='list-group'>";
              echo "<li class='list-group-item'>Marka: " .$row['model']."</li>";
              echo "<li class='list-group-item'>Model: " .$row['marka']."</li>";
              echo "<li class='list-group-item'>Rok: " .$row['rocznik']. "</li>";
              echo "<li class='list-group-item'>Przebieg: " .$row['przebieg']. "</li>";
              echo "<li class='list-group-item'>Moc: " .$row['moc']."</li>";
              echo "<li class='list-group-item'>Cena: " .$row['cena']. "</li>";
              echo "<li class='list-group-item'>Paliwo: " .$row['paliwo']. "</li>";
            echo"</ul>";
         echo "</div>";
        echo "</div>";
    }
   ?>
  </div>
      
  </div>
  </div>
   
<footer>MobileGET</footer>

  </body>
</html>
